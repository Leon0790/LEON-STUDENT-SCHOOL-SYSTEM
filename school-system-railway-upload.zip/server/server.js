const express = require("express")
const mongoose = require("mongoose")
const cors = require("cors")
const bcrypt = require("bcryptjs")
const jwt = require("jsonwebtoken")

const app = express()

app.use(cors())
app.use(express.json())

mongoose.connect(process.env.MONGO_URI || "mongodb://localhost/school")

const Teacher = mongoose.model("Teacher",{
    email:String,
    password:String,
    phone:String,
    paid:{type:Boolean,default:false}
})

const Student = mongoose.model("Student",{
    teacherId:String,
    name:String,
    grade:Number,
    term:String,
    math:Number,
    english:Number,
    kiswahili:Number,
    science:Number,
    social:Number,
    total:Number,
    mean:Number,
    rank:Number
})

const SECRET="school_secret"

app.post("/register", async(req,res)=>{

    const {email,password} = req.body
    const hash = await bcrypt.hash(password,10)

    const teacher = await Teacher.create({
        email,
        password:hash
    })

    res.json(teacher)

})

app.post("/login", async(req,res)=>{

    const {email,password} = req.body

    const teacher = await Teacher.findOne({email})

    if(!teacher) return res.json({error:"invalid login"})

    const valid = await bcrypt.compare(password,teacher.password)

    if(!valid) return res.json({error:"invalid login"})

    const token = jwt.sign({id:teacher._id},SECRET)

    res.json({
        token,
        teacherId:teacher._id,
        paid:teacher.paid
    })

})

function calculateResults(student){

    const total =
    student.math +
    student.english +
    student.kiswahili +
    student.science +
    student.social

    const mean = total/5

    return {total,mean}

}

app.post("/student", async(req,res)=>{

    const data = req.body

    const results = calculateResults(data)

    const student = await Student.create({
        ...data,
        total:results.total,
        mean:results.mean
    })

    res.json(student)

})

app.get("/students/:teacherId", async(req,res)=>{

    const students = await Student.find({
        teacherId:req.params.teacherId
    })

    students.sort((a,b)=>b.total-a.total)

    students.forEach((s,i)=>{
        s.rank = i+1
    })

    res.json(students)

})

app.listen(3000,()=>{
    console.log("server running on port 3000")
})