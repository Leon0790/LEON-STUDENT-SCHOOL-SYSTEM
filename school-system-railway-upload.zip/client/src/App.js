import React from "react"

export default function App(){

return (
<div style={{padding:20}}>

<h1>School Performance Dashboard</h1>

<p>This is the mobile dashboard UI.</p>

</div>
)

}